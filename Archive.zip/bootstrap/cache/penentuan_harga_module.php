<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PenentuanHarga\\Providers\\PenentuanHargaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PenentuanHarga\\Providers\\PenentuanHargaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);