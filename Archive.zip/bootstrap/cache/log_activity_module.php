<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LogActivity\\Providers\\LogActivityServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LogActivity\\Providers\\LogActivityServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);