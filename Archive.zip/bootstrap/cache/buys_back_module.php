<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BuysBack\\Providers\\BuysBackServiceProvider',
    1 => 'Modules\\BuysBack\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BuysBack\\Providers\\BuysBackServiceProvider',
    1 => 'Modules\\BuysBack\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);