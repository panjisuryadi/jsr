<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DataSale\\Providers\\DataSaleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DataSale\\Providers\\DataSaleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);