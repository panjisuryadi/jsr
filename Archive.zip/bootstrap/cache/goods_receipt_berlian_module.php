<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GoodsReceiptBerlian\\Providers\\GoodsReceiptBerlianServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GoodsReceiptBerlian\\Providers\\GoodsReceiptBerlianServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);