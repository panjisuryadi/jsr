<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Gudang\\Providers\\GudangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Gudang\\Providers\\GudangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);