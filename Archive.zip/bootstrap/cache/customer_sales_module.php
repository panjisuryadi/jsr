<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomerSales\\Providers\\CustomerSalesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomerSales\\Providers\\CustomerSalesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);