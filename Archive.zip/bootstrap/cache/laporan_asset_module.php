<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LaporanAsset\\Providers\\LaporanAssetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LaporanAsset\\Providers\\LaporanAssetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);