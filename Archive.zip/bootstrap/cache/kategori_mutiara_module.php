<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KategoriMutiara\\Providers\\KategoriMutiaraServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KategoriMutiara\\Providers\\KategoriMutiaraServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);