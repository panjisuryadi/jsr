<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JenisBuyBack\\Providers\\JenisBuyBackServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JenisBuyBack\\Providers\\JenisBuyBackServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);