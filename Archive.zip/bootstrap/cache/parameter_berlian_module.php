<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ParameterBerlian\\Providers\\ParameterBerlianServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ParameterBerlian\\Providers\\ParameterBerlianServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);