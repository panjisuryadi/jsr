<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ReturPembelian\\Providers\\ReturPembelianServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ReturPembelian\\Providers\\ReturPembelianServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);