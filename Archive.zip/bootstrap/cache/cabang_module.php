<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cabang\\Providers\\CabangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cabang\\Providers\\CabangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);