<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JenisPerak\\Providers\\JenisPerakServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JenisPerak\\Providers\\JenisPerakServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);