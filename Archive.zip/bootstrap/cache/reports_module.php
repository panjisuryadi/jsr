<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Reports\\Providers\\ReportsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Reports\\Providers\\ReportsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);