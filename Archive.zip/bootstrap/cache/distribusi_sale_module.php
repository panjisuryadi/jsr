<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DistribusiSale\\Providers\\DistribusiSaleServiceProvider',
    1 => 'Modules\\DistribusiSale\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DistribusiSale\\Providers\\DistribusiSaleServiceProvider',
    1 => 'Modules\\DistribusiSale\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);