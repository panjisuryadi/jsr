<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GoldCategory\\Providers\\GoldCategoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GoldCategory\\Providers\\GoldCategoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);