<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KategoriProduk\\Providers\\KategoriProdukServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KategoriProduk\\Providers\\KategoriProdukServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);