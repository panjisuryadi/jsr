<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DistribusiToko\\Providers\\DistribusiTokoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DistribusiToko\\Providers\\DistribusiTokoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);