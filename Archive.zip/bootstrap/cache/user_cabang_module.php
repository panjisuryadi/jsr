<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserCabang\\Providers\\UserCabangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserCabang\\Providers\\UserCabangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);