<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GoodsReceipt\\Providers\\GoodsReceiptServiceProvider',
    1 => 'Modules\\GoodsReceipt\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GoodsReceipt\\Providers\\GoodsReceiptServiceProvider',
    1 => 'Modules\\GoodsReceipt\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);