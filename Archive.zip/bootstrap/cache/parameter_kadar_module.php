<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ParameterKadar\\Providers\\ParameterKadarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ParameterKadar\\Providers\\ParameterKadarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);