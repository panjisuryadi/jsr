<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PenjualanSale\\Providers\\PenjualanSaleServiceProvider',
    1 => 'Modules\\PenjualanSale\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PenjualanSale\\Providers\\PenjualanSaleServiceProvider',
    1 => 'Modules\\PenjualanSale\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);