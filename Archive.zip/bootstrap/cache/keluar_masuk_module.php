<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KeluarMasuk\\Providers\\KeluarMasukServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KeluarMasuk\\Providers\\KeluarMasukServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);