<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PenerimaanBarangLuar\\Providers\\PenerimaanBarangLuarServiceProvider',
    1 => 'Modules\\PenerimaanBarangLuar\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PenerimaanBarangLuar\\Providers\\PenerimaanBarangLuarServiceProvider',
    1 => 'Modules\\PenerimaanBarangLuar\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);