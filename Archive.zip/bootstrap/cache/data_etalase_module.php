<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DataEtalase\\Providers\\DataEtalaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DataEtalase\\Providers\\DataEtalaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);