<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KodeTransaksi\\Providers\\KodeTransaksiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KodeTransaksi\\Providers\\KodeTransaksiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);