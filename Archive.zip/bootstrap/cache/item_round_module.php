<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ItemRound\\Providers\\ItemRoundServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ItemRound\\Providers\\ItemRoundServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);