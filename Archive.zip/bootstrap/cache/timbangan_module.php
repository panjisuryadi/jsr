<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Timbangan\\Providers\\TimbanganServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Timbangan\\Providers\\TimbanganServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);