<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CostParameter\\Providers\\CostParameterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CostParameter\\Providers\\CostParameterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);