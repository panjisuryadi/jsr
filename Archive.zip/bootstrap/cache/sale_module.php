<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sale\\Providers\\SaleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sale\\Providers\\SaleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);