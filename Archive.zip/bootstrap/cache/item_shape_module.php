<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ItemShape\\Providers\\ItemShapeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ItemShape\\Providers\\ItemShapeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);