<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JenisMutiara\\Providers\\JenisMutiaraServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JenisMutiara\\Providers\\JenisMutiaraServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);