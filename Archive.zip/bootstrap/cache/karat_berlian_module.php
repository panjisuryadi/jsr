<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KaratBerlian\\Providers\\KaratBerlianServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KaratBerlian\\Providers\\KaratBerlianServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);