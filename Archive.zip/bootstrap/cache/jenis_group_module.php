<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JenisGroup\\Providers\\JenisGroupServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JenisGroup\\Providers\\JenisGroupServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);