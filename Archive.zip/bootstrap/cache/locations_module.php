<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Locations\\Providers\\LocationsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Locations\\Providers\\LocationsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);