<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserLogin\\Providers\\UserLoginServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserLogin\\Providers\\UserLoginServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);