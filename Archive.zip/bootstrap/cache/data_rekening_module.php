<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DataRekening\\Providers\\DataRekeningServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DataRekening\\Providers\\DataRekeningServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);