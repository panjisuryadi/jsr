<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProdukModel\\Providers\\ProdukModelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProdukModel\\Providers\\ProdukModelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);