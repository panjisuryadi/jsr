<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StokCabang\\Providers\\StokCabangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StokCabang\\Providers\\StokCabangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);