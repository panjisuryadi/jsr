<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DataBank\\Providers\\DataBankServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DataBank\\Providers\\DataBankServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);