<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Status\\Providers\\StatusServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Status\\Providers\\StatusServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);