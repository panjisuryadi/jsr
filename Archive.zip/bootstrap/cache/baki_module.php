<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Baki\\Providers\\BakiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Baki\\Providers\\BakiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);