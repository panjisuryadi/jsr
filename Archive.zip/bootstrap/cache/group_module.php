<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Group\\Providers\\GroupServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Group\\Providers\\GroupServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);