<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KondisiBarang\\Providers\\KondisiBarangServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KondisiBarang\\Providers\\KondisiBarangServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);