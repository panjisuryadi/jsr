<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ReturSale\\Providers\\ReturSaleServiceProvider',
    1 => 'Modules\\ReturSale\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ReturSale\\Providers\\ReturSaleServiceProvider',
    1 => 'Modules\\ReturSale\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);