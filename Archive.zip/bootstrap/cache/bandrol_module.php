<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bandrol\\Providers\\BandrolServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bandrol\\Providers\\BandrolServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);