<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MarketPlace\\Providers\\MarketPlaceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MarketPlace\\Providers\\MarketPlaceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);