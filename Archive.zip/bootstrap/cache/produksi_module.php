<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Produksi\\Providers\\ProduksiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Produksi\\Providers\\ProduksiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);