<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Exhibition\\Providers\\ExhibitionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Exhibition\\Providers\\ExhibitionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);