<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DiamondCertificate\\Providers\\DiamondCertificateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DiamondCertificate\\Providers\\DiamondCertificateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);