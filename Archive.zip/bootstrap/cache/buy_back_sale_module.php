<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BuyBackSale\\Providers\\BuyBackSaleServiceProvider',
    1 => 'Modules\\BuyBackSale\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BuyBackSale\\Providers\\BuyBackSaleServiceProvider',
    1 => 'Modules\\BuyBackSale\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);