<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PenerimaanBarangLuarSale\\Providers\\PenerimaanBarangLuarSaleServiceProvider',
    1 => 'Modules\\PenerimaanBarangLuarSale\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PenerimaanBarangLuarSale\\Providers\\PenerimaanBarangLuarSaleServiceProvider',
    1 => 'Modules\\PenerimaanBarangLuarSale\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);