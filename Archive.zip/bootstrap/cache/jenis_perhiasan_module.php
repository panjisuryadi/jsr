<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JenisPerhiasan\\Providers\\JenisPerhiasanServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JenisPerhiasan\\Providers\\JenisPerhiasanServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);