<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PurchasesReturn\\Providers\\PurchasesReturnServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PurchasesReturn\\Providers\\PurchasesReturnServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);