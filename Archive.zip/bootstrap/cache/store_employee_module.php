<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StoreEmployee\\Providers\\StoreEmployeeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StoreEmployee\\Providers\\StoreEmployeeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);