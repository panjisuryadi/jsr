<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Accessory\\Providers\\AccessoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Accessory\\Providers\\AccessoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);