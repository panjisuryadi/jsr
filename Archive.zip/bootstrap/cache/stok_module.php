<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Stok\\Providers\\StokServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Stok\\Providers\\StokServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);