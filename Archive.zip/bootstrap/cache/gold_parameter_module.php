<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GoldParameter\\Providers\\GoldParameterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GoldParameter\\Providers\\GoldParameterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);