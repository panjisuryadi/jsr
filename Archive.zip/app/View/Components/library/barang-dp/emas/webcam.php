<?php

namespace App\View\Components\library\barang-dp\emas;

use Illuminate\View\Component;

class webcam extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.library.barang-dp.emas.webcam');
    }
}
